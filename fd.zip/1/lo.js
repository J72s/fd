///////////////////////////
///
// Importing the config.js file
const token = require('./config.js').token;

// Output the token to ensure it's retrieved correctly
console.log("Token from config.js:", token);

module.exports = {
    showTime: false, // Toggle to show or hide time in status (true/false)
    token: token,
    timeZone: "Asia/Kolkata", //Your Timezone, eg Asia/Kolkata
    Name: "Eric Music",
    State: "Just shut up",
    Details: "ُُEric bot",
    FirstButtonName: "My Server",
    FirstButtonUrl: "https://discord.gg/KGnvcT5A8V",
    LargeImage: "https://cdn.discordapp.com/attachments/1239345562663256065/1245838967300165683/651b2b12e01d3a21fad1bf639cfa0b81.gif?ex=665a3574&is=6658e3f4&hm=88eb933dc62acf4af1a3107f4d0e86198313cfb0ad40c165ba49dccb5116e43a&",
    LargeText: "Eric", // hover text for large image
    SmallImage: "https://cdn.discordapp.com/attachments/1239345562663256065/1245838954113011732/e6c64ae5e192b4faf1069311a2f38e39.gif?ex=665a3571&is=6658e3f1&hm=a10c22e65e246de5c0efd344ba9efd12004dc20a41484b7bfa41a683692e75e3&",
     SmallText: "...", // hover text for small image
  };
  