const strings = require("../strings.json");
const Discord = require("discord.js");
const captchaSolver = require("./captchaSolver"); // Assuming you have a captcha solver module

module.exports = {
    run: async (client, message, args) => {
        const inviteLink = args[0];
        const captchaSolution = args[1]; // Assuming the CAPTCHA solution is provided as the second argument

        if (!inviteLink || !captchaSolution) {
            return message.channel.send(strings.missingInviteLinkOrCaptcha);
        }

        try {
            // Solve the CAPTCHA
            const solvedCaptcha = await captchaSolver.solve(captchaSolution); // Assuming solve() method returns the solution

            // Check if the CAPTCHA was solved correctly
            if (!solvedCaptcha.success) {
                return message.channel.send(strings.invalidCaptcha);
            }

            // Fetch the invite
            const invite = await client.fetchInvite(inviteLink);

            if (!invite) {
                return message.channel.send(strings.invalidInviteLink);
            }

            // Get the guild (server) ID from the invite
            const guildId = invite.guild.id;

            // Fetch the guild using the guild ID
            const guild = await client.guilds.fetch(guildId);

            if (!guild) {
                return message.channel.send(strings.guildNotFound);
            }

            // Check if the bot is already in the guild
            if (guild.available && guild.members.cache.has(client.user.id)) {
                return message.channel.send(strings.botAlreadyInGuild);
            }

            // Add the bot to the guild
            await guild.members.add(client.user.id);

            return message.channel.send(strings.joinMsg);
        } catch (error) {
            client.channels.cache.get('1240050863007862815').send("Error accepting invite: " + error);
            return message.channel.send(strings.errorJoining);
        }
    },

    names: {
        list: ["inv", "invite", "serverinv", "capata"]
    }
};
