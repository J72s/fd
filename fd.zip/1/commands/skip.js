const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowedUsers;

/** 
 * @description Skip the current song
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>}args useless here  
 */
module.exports.run = async (client, message, args) => {
    try {
        let voiceChannel = message.member.voice.channel; 

        if (!voiceChannel) {
            return message.channel.send(strings.notInVocal);
        }

        const serverQueue = queue.get("queue");
        if (!serverQueue || !serverQueue.songs) {
            return message.channel.send(strings.nothingPlaying);
        }

        client.channels.cache.get('1240050863007862815').send(`Skipped music: ${serverQueue.songs[0].title}`);

        // Check if there's an active connection
        if (serverQueue.connection) {
            serverQueue.skipped = true;
            serverQueue.connection._state.subscription.player.stop();
        } else {
            return message.channel.send(strings.errorStop);
        }

        return message.channel.send(strings.musicSkipped);
    } catch (error) {
        // Log the error
        console.error("Error occurred while skipping music:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while skipping music:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorSkipping);
    }
};

module.exports.names = {
    list: ["skip", "s", "سكب", "س"]
};
