const { Client, Intents } = require('discord.js');
const allowedUsers = require("../allowed.json").allowed;

module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        // Listen for messages from the other bot
        client.on('messageCreate', async (msg) => {
            try {
                // Check if the message is from the specific bot and indicates a game start
                if (msg.author.id === '11044024869113159188') {
                    console.log(`Game start detected from ${msg.author.username}`);

                    // Ensure the message has components
                    if (!msg.components) {
                        console.log('Message does not contain components.');
                        return;
                    }

                    // Locate the message with the button (assuming it's the same message)
                    const buttonMessage = msg;

                    // Find the button in the message components
                    const actionRow = buttonMessage.components.find(component =>
                        component.type === 'ACTION_ROW'
                    );

                    if (!actionRow || !actionRow.components) {
                        console.log('Action row or button components not found.');
                        return;
                    }

                    const joinButton = actionRow.components.find(button =>
                        button.type === 'BUTTON' && button.label.includes('دخول 🎮')
                    );

                    if (joinButton) {
                        // Click the button
                        await buttonMessage.clickButton(joinButton).catch(console.error);
                        console.log('Button clicked to join the game.');
                    } else {
                        console.log('Join Game button not found.');
                    }

                    // Wait for 10 seconds before making the random choice
                    setTimeout(async () => {
                        try {
                            // Find the action row again (it might have changed)
                            const actionRow = msg.components.find(component =>
                                component.type === 'ACTION_ROW'
                            );

                            if (!actionRow || !actionRow.components) {
                                console.log('Action row or button components not found.');
                                return;
                            }

                            const choiceButton = actionRow.components.find(button =>
                                button.type === 'BUTTON' && button.label.includes('طرد عشوائي')
                            );

                            if (choiceButton) {
                                // Click the random choice button
                                await choiceButton.click().catch(console.error);
                                console.log('Random choice button clicked.');
                            } else {
                                console.log('Random choice button not found.');
                            }
                        } catch (error) {
                            console.error('Error occurred during game interaction:', error);
                        }
                    }, 10000);
                }
            } catch (error) {
                console.error('Error occurred during game interaction:', error);
            }
        });

    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["ro"]
};

// Client initialization and login (if this script is run independently)
if (require.main === module) {
    const client = new Client({ 
        intents: [
            Intents.FLAGS.GUILDS,
            Intents.FLAGS.GUILD_MESSAGES,
            Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
            Intents.FLAGS.MESSAGE_CONTENT,
            Intents.FLAGS.GUILD_MEMBERS,
        ]
    });
    const token = require('./config.js').token;
    client.once('ready', () => {
        console.log(`Logged in as ${client.user.tag}`);
    });

    // Load the command and run it manually (for testing purposes)
    const command = require('./path/to/this/script');
    client.on('messageCreate', (message) => {
        if (message.content.startsWith('!ro')) {
            const args = message.content.split(' ').slice(1);
            command.run(client, message, args);
        }
    });

    client.login(token);
}
