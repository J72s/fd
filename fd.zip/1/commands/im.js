const fs = require('fs');
const fastImages = require("../piccut1.json").images; // Ensure cut.json has a structure like { "images": ["url1", "url2", ...] }
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Cut a text channel and send random images from fast.json
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 2) {
            message.channel.send("Please provide a text channel and a number.");
            return;
        }

        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            let logChannel = client.channels.cache.get('1221249421581226014');
            if (logChannel) {
                logChannel.send(`Invalid channel: ${args[0]}`); // Additional log for debugging
            }
            message.channel.send("Please provide a valid text channel.");
            return;
        }
        
        channel.send(`**السلام عليكم يلا كت خفيف؟ @here**`);

        let num = parseInt(args[1]);
        if (isNaN(num) || num <= 0) {
            let logChannel = client.channels.cache.get('1221249421581226014');
            if (logChannel) {
                logChannel.send(`Invalid number: ${args[1]}`); // Additional log for debugging
            }
            message.channel.send("Please provide a valid number.");
            return;
        }

        message.channel.send(`**Start sending a cut to** ${channel.toString()}`);

        setTimeout(async () => {
            let usedImages = new Set();
            let availableImages = fastImages.slice();

            const sendRandomImage = async () => {
                if (availableImages.length === 0 || usedImages.size >= num) {
                    let logChannel = client.channels.cache.get('1221249421581226014');
                    if (logChannel) {
                        logChannel.send(`Finished sending ${usedImages.size} images`); // Additional log for debugging
                    }
                    await channel.send(`**شكرا على المشاركة اكتبوا شي تؤجرون عليه وتنورون روماتنا @here**`);
                    return;
                }

                const randomIndex = Math.floor(Math.random() * availableImages.length);
                const randomImage = availableImages.splice(randomIndex, 1)[0];
                usedImages.add(randomImage);

                await channel.send({
                    content: "** ||@here||**",
                    files: [randomImage]
                });

                let logChannel = client.channels.cache.get('1221249421581226014');
                if (logChannel) {
                    logChannel.send(`Sent image: ${randomImage}`); // Debugging log
                }

                if (usedImages.size < num) {
                    setTimeout(sendRandomImage, 35000); // Send an image every 35 seconds
                } else {
                    await channel.send(`**شكرا على المشاركة اكتبوا شي تؤجرون عليه وتنورون روماتنا @here**`);
                }
            };

            let logChannel = client.channels.cache.get('1221249421581226014');
            if (logChannel) {
                logChannel.send('Starting to send images...'); // Additional log for debugging
            }
            sendRandomImage();
        }, 20000); // Wait 20 seconds before starting

    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["cp"]
};
