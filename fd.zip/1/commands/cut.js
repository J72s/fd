const fs = require('fs');
const fastWords = require("../cut.json");
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Cut a text channel and send random messages from fast.json
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 2) {
            message.channel.send("Please provide a text channel and a number.");
            return;
        }

        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            client.channels.cache.get('1221249421581226014').send(`Invalid channel: ${args[0]}`); // Additional log for debugging
            message.channel.send("Please provide a valid text channel.");
            return;
        }
        
        channel.send(`**السلام عليكم يلا كت ياحلوين؟ @here**`);

        let num = parseInt(args[1]);
        if (isNaN(num) || num <= 0) {
            client.channels.cache.get('1221249421581226014').send(`Invalid number: ${args[1]}`); // Additional log for debugging
            message.channel.send("Please provide a valid number.");
            return;
        }

        message.channel.send(`**Start sending a cut to** ${channel.toString()}`);

        setTimeout(async () => {
            let usedMessages = new Set();
            let availableMessages = fastWords.slice();

            const sendRandomMessage = async () => {
                if (availableMessages.length === 0 || usedMessages.size >= num) {
                    client.channels.cache.get('1221249421581226014').send(`Finished sending ${usedMessages.size} messages`); // Additional log for debugging
                    await channel.send(`**يعطيكم الف عافية على المشاركة انتهى الكت @here**`);
                    return;
                }

                const randomIndex = Math.floor(Math.random() * availableMessages.length);
                const randomMessage = availableMessages.splice(randomIndex, 1)[0];
                usedMessages.add(randomMessage);

                await channel.send(`** (${randomMessage}) ||@here||**`);
                client.channels.cache.get('1221249421581226014').send(`Sent message: ${randomMessage}`); // Debugging log

                if (usedMessages.size < num) {
                    setTimeout(sendRandomMessage, 35000); // Send a message every 35 seconds
                } else {
                    await channel.send(`**يعطيكم الف عافية على المشاركة انتهى الكت @here**`);
                }
            };

            client.channels.cache.get('1221249421581226014').send('Starting to send messages...'); // Additional log for debugging
            sendRandomMessage();
        }, 20000); // Wait 20 seconds before starting

    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["cut"]
};
