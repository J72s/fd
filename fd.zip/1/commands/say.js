const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Send a text message to a specified channel
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 2) {
            message.channel.send("Please provide a text channel and a message.");
            return;
        }

        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            message.channel.send("Please provide a valid text channel.");
            return;
        }

        // Extract the message to send
        const textMessage = args.slice(1).join(" ");

        await channel.send(textMessage);

        message.channel.send(`Message sent to ${channel.toString()}`);
    } catch (error) {
        console.error("Error occurred while sending the message:", error);
        message.channel.send("An error occurred while trying to send the message.");
    }
};

module.exports.names = {
    list: ["say"]
};
