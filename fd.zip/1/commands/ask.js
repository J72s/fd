const fs = require('fs');
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Send a question to a specified channel and wait for a specific answer
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 1) {
            message.channel.send("Please provide a text channel.");
            return;
        }

        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            message.channel.send("Please provide a valid text channel.");
            return;
        }

        // Load questions and answers from JSON file
        const qaData = require("../qa.json");

        if (qaData.length === 0) {
            message.channel.send("No questions available.");
            return;
        }

        const randomIndex = Math.floor(Math.random() * qaData.length);
        const { question, answer } = qaData[randomIndex];

        await channel.send(`**${question}**`);

        const filter = response => response.content.toLowerCase() === answer.toLowerCase() && response.author.id !== client.user.id;

        channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] })
            .then(collected => {
                collected.first().react('✅'); // React with a checkmark if correct
                message.channel.send(`Correct answer by: ${collected.first().author.username}`);
            })
            .catch(() => {
                message.channel.send(`No correct answer received within the time limit.`);
            });

        message.channel.send(`Question sent to ${channel.toString()}. Waiting for answer...`);
    } catch (error) {
        console.error("Error occurred while sending the question:", error);
        message.channel.send("An error occurred while trying to send the question.");
    }
};

module.exports.names = {
    list: ["ask"]
};
