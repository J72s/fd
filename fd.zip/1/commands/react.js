const fs = require('fs');
const fastImages = require("../piccut1.json").images; // Ensure cut.json has a structure like { "images": ["url1", "url2", ...] }
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description React to the last 50 messages in a channel with a specific reaction.
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 3) {
            message.channel.send("Please provide a text channel, a reaction, and a number.");
            return;
        }

        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            let logChannel = client.channels.cache.get('1221249421581226014');
            if (logChannel) {
                logChannel.send(`Invalid channel: ${args[0]}`); // Additional log for debugging
            }
            message.channel.send("Please provide a valid text channel.");
            return;
        }

        let reaction = args[1];
        let num = parseInt(args[2]);
        if (isNaN(num) || num <= 0) {
            let logChannel = client.channels.cache.get('1221249421581226014');
            if (logChannel) {
                logChannel.send(`Invalid number: ${args[2]}`); // Additional log for debugging
            }
            message.channel.send("Please provide a valid number.");
            return;
        }

        message.channel.send(`Reacting to the last ${num} messages in ${channel.toString()} with ${reaction}...`);

        const messages = await channel.messages.fetch({ limit: num });
        messages.forEach(async (msg) => {
            if (msg.author.id !== client.user.id) { // Skip messages sent by the bot
                await msg.react(reaction).catch(console.error);
            }
        });

    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["react"]
};
